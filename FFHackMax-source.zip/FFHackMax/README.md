# FF Max Hack v2.0

Non-root hack for Free Fire Max using Shizuku + VPN dual layer.

## Features
- Aimbot + Aim Kill + On-Fire aim
- Speed Hack (memory + packet)
- Fly Hack
- Location Spoof / Teleport
- No Recoil
- Unlimited Ammo
- No Reload
- Wallhack ESP
- Super Jump
- Rapid Fire
- Invisible
- Anti-Ban (memory + packet drop)

## Build

### Android Studio
1. Open project
2. `Build → Generate Signed Bundle/APK`

### GitHub Actions (auto build)
1. Push to `main` branch → debug + release APK built automatically
2. Push a tag `v1.0.0` → creates GitHub release with APK attached

### CLI
```bash
chmod +x gradlew
./gradlew assembleDebug
# output: app/build/outputs/apk/debug/app-debug.apk
```

## Setup Secrets (for signed release)
Go to repo → Settings → Secrets → Actions:
```
KEYSTORE_BASE64     base64 encoded .keystore file
KEYSTORE_PASSWORD   store password
KEY_ALIAS           key alias
KEY_PASSWORD        key password
```

Generate keystore:
```bash
keytool -genkey -v -keystore ffhack.keystore -alias ffhack \
  -keyalg RSA -keysize 2048 -validity 36500 \
  -storepass yourpass -keypass yourpass \
  -dname "CN=FFHack,O=FFHack,C=US"

base64 -w 0 ffhack.keystore
# paste output into KEYSTORE_BASE64 secret
```

## Usage
1. Install Shizuku from Play Store
2. Settings → Developer Options → Wireless Debugging → enable
3. Open Shizuku → Start via Wireless Debugging
4. Install this APK (allow unknown sources)
5. Open app → grant overlay + VPN permissions
6. Launch Free Fire Max
7. Tap ⚡ floating button → toggle hacks
