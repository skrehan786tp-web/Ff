package com.ffhack.max.modules

import com.ffhack.max.MemoryUtils
import com.ffhack.max.MemoryUtils.Offsets
import com.ffhack.max.VpnHackService

object SpeedFlyModule {

    var speedEnabled = false
    var flyEnabled   = false
    var speedMul     = 2.5f
    var flyHeight    = 5.5f

    private var pid  = -1
    private var base = 0L

    fun setup(pid: Int, base: Long) { this.pid = pid; this.base = base }

    fun apply() {
        if (pid == -1 || base == 0L) return
        val local = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return

        if (speedEnabled) {
            MemoryUtils.writeFloat(pid, local + Offsets.MOVE_SPEED, Offsets.BASE_SPEED * speedMul)
        }

        if (flyEnabled) {
            MemoryUtils.writeFloat(pid, base + 0x8F12A40L, -0.01f)
            MemoryUtils.writeFloat(pid, local + 0x94L, flyHeight)
        } else {
            MemoryUtils.writeFloat(pid, base + 0x8F12A40L, -9.81f)
        }

        VpnHackService.cfg.speedMul   = if (speedEnabled) speedMul else 1.0f
        VpnHackService.cfg.flyEnabled = flyEnabled
    }

    fun disable() {
        if (pid == -1 || base == 0L) return
        val local = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return
        MemoryUtils.writeFloat(pid, local + Offsets.MOVE_SPEED, Offsets.BASE_SPEED)
        MemoryUtils.writeFloat(pid, base + 0x8F12A40L, -9.81f)
        VpnHackService.cfg.speedMul   = 1.0f
        VpnHackService.cfg.flyEnabled = false
    }
}
