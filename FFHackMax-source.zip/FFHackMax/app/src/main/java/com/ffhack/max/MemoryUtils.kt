package com.ffhack.max

import java.nio.ByteBuffer
import java.nio.ByteOrder

object MemoryUtils {

    object Offsets {
        const val BASE_LIBRARY        = "libil2cpp.so"
        const val LOCAL_PLAYER        = 0x9E12BC8L
        const val PLAYER_LIST         = 0x9E12B80L
        const val POS_X               = 0x80L
        const val POS_Y               = 0x84L
        const val POS_Z               = 0x88L
        const val HEAD_BONE           = 0x16CL
        const val NECK_BONE           = 0x168L
        const val CHEST_BONE          = 0x164L
        const val PLAYER_HP           = 0x254L
        const val PLAYER_MAX_HP       = 0x258L
        const val MOVE_SPEED          = 0x160L
        const val BASE_SPEED          = 4.5f
        const val WEAPON_DAMAGE       = 0x218L
        const val AMMO_COUNT          = 0x1F4L
        const val RELOAD_TIME         = 0x204L
        const val RECOIL_X            = 0x340L
        const val RECOIL_Y            = 0x344L
        const val TEAM_ID             = 0x10CL
        const val ANTICHEAT_FLAG      = 0xA1F3C40L
        const val REPORT_FLAG         = 0xA1F3C44L
    }

    fun readFloat(pid: Int, addr: Long): Float? {
        val b = ShizukuManager.readMemory(pid, addr, 4) ?: return null
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).float
    }

    fun writeFloat(pid: Int, addr: Long, v: Float): Boolean {
        val b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putFloat(v).array()
        return ShizukuManager.writeMemory(pid, addr, b)
    }

    fun readInt(pid: Int, addr: Long): Int? {
        val b = ShizukuManager.readMemory(pid, addr, 4) ?: return null
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).int
    }

    fun writeInt(pid: Int, addr: Long, v: Int): Boolean {
        val b = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v).array()
        return ShizukuManager.writeMemory(pid, addr, b)
    }

    fun readLong(pid: Int, addr: Long): Long? {
        val b = ShizukuManager.readMemory(pid, addr, 8) ?: return null
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).long
    }
}
