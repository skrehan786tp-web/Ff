package com.ffhack.max

import android.content.pm.PackageManager
import android.util.Log
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuRemoteProcess

object ShizukuManager {

    private const val REQUEST_CODE = 9201
    private const val TAG = "ShizukuManager"

    var isAvailable = false
    var isGranted   = false

    var onGranted:    (() -> Unit)? = null
    var onDenied:     (() -> Unit)? = null
    var onBinderDead: (() -> Unit)? = null

    // ── lifecycle ─────────────────────────────────────────────────────────
    fun init() {
        Shizuku.addBinderReceivedListenerSticky(binderListener)
        Shizuku.addBinderDeadListener(deadListener)
        Shizuku.addRequestPermissionResultListener(permListener)
    }

    fun destroy() {
        Shizuku.removeBinderReceivedListener(binderListener)
        Shizuku.removeBinderDeadListener(deadListener)
        Shizuku.removeRequestPermissionResultListener(permListener)
    }

    // ── listeners ──────────────────────────────────────────────────────────
    private val binderListener = Shizuku.OnBinderReceivedListener {
        isAvailable = true
        Log.d(TAG, "binder received v${Shizuku.getVersion()}")
        if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
            isGranted = true
            onGranted?.invoke()
        } else {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    private val deadListener = Shizuku.OnBinderDeadListener {
        isAvailable = false
        isGranted   = false
        onBinderDead?.invoke()
    }

    private val permListener =
        Shizuku.OnRequestPermissionResultListener { code, result ->
            if (code == REQUEST_CODE) {
                isGranted = result == PackageManager.PERMISSION_GRANTED
                if (isGranted) onGranted?.invoke() else onDenied?.invoke()
            }
        }

    // ── shell ──────────────────────────────────────────────────────────────
    fun exec(cmd: String): String {
        if (!isGranted) return ""
        return try {
            val proc: ShizukuRemoteProcess = Shizuku.newProcess(
                arrayOf("sh", "-c", cmd), null, null
            )
            val out = proc.inputStream.bufferedReader().readText().trim()
            proc.waitFor(); proc.destroy()
            out
        } catch (e: Exception) {
            Log.e(TAG, "exec: ${e.message}")
            ""
        }
    }

    fun execAsync(cmd: String, cb: (String) -> Unit = {}) {
        Thread { cb(exec(cmd)) }.also { it.isDaemon = true }.start()
    }

    // ── process ────────────────────────────────────────────────────────────
    fun getPid(pkg: String): Int =
        exec("pidof $pkg").trim().split("\\s+".toRegex())
            .firstOrNull()?.toIntOrNull() ?: -1

    fun isRunning(pkg: String) = getPid(pkg) != -1

    // ── memory ────────────────────────────────────────────────────────────
    fun readMemory(pid: Int, address: Long, size: Int): ByteArray? {
        if (!isGranted || pid < 1) return null
        return try {
            val tmp = "/data/local/tmp/r_${System.nanoTime()}"
            exec("dd if=/proc/$pid/mem of=$tmp bs=1 skip=$address count=$size 2>/dev/null")
            val hex = exec("xxd -p $tmp").replace("\n","").replace(" ","")
            exec("rm -f $tmp")
            if (hex.isEmpty()) null
            else hex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (e: Exception) { null }
    }

    fun writeMemory(pid: Int, address: Long, data: ByteArray): Boolean {
        if (!isGranted || pid < 1) return false
        return try {
            val hex = data.joinToString("") { "%02x".format(it) }
            val tmp = "/data/local/tmp/w_${System.nanoTime()}"
            exec("printf '$hex' | xxd -r -p > $tmp 2>/dev/null")
            exec("dd if=$tmp of=/proc/$pid/mem bs=1 seek=$address conv=notrunc 2>/dev/null")
            exec("rm -f $tmp")
            true
        } catch (e: Exception) { false }
    }

    // ── maps ──────────────────────────────────────────────────────────────
    fun getLibBase(pid: Int, lib: String): Long {
        val maps = exec("cat /proc/$pid/maps")
        for (line in maps.lines()) {
            if (line.contains(lib) && line.contains("r-xp")) {
                return line.substringBefore("-").toLongOrNull(16) ?: continue
            }
        }
        return 0L
    }

    // ── input injection ───────────────────────────────────────────────────
    fun injectSwipe(x1: Int, y1: Int, x2: Int, y2: Int, ms: Int = 10) {
        execAsync("input touchscreen swipe $x1 $y1 $x2 $y2 $ms")
    }

    fun injectTap(x: Int, y: Int) {
        execAsync("input touchscreen tap $x $y")
    }

    fun status(): String = buildString {
        appendLine("Shizuku : $isAvailable")
        appendLine("Granted : $isGranted")
        if (isAvailable) appendLine("Version : ${Shizuku.getVersion()}")
    }
}
