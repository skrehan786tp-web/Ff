package com.ffhack.max

import android.app.Activity
import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.widget.*
import com.ffhack.max.modules.*
import kotlinx.coroutines.*

class MainActivity : Activity() {

    private val VPN_REQ = 100
    private var statusJob: Job? = null
    private lateinit var tvStatus: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvStatus = findViewById(R.id.tvStatus)

        ShizukuManager.init()

        ShizukuManager.onGranted = {
            runOnUiThread { onShizukuReady() }
        }
        ShizukuManager.onDenied = {
            runOnUiThread {
                toast("Shizuku permission denied — open Shizuku app and grant access")
            }
        }
        ShizukuManager.onBinderDead = {
            runOnUiThread { toast("Shizuku died — restart it from the Shizuku app") }
        }

        checkOverlay()
        startVPN()

        findViewById<Button>(R.id.btnLaunchFF).setOnClickListener {
            packageManager.getLaunchIntentForPackage("com.dts.freefiremax")
                ?.also { startActivity(it) }
                ?: toast("Free Fire Max not installed")
        }

        statusJob = CoroutineScope(Dispatchers.Main).launch {
            while (true) {
                updateStatus()
                delay(2000)
            }
        }
    }

    private fun onShizukuReady() {
        val pid  = ShizukuManager.getPid("com.dts.freefiremax")
        val base = if (pid != -1) ShizukuManager.getLibBase(pid, "libil2cpp.so") else 0L

        AimbotModule.setup(pid, base)
        SpeedFlyModule.setup(pid, base)
        LocationModule.setup(pid, base)
        MiscModule.setup(pid, base)

        startService(Intent(this, FloatingMenuService::class.java))
        updateStatus()
    }

    private fun checkOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:$packageName")
            ))
        }
    }

    private fun startVPN() {
        val i = VpnService.prepare(this)
        if (i != null) startActivityForResult(i, VPN_REQ)
        else startService(Intent(this, VpnHackService::class.java))
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        if (req == VPN_REQ && res == RESULT_OK)
            startService(Intent(this, VpnHackService::class.java))
    }

    private fun updateStatus() {
        val pid = ShizukuManager.getPid("com.dts.freefiremax")
        tvStatus.text = """
┌─────────────────────────────┐
│   FF MAX HACK v2.0          │
├─────────────────────────────┤
│ Shizuku : ${if (ShizukuManager.isGranted) "✅ CONNECTED  " else "❌ WAITING    "}│
│ FF Max  : ${if (pid != -1) "✅ PID $pid  " else "❌ NOT RUNNING"}│
│ VPN     : ✅ ACTIVE         │
│ Overlay : ${if (Settings.canDrawOverlays(this)) "✅ GRANTED    " else "❌ NEEDED     "}│
└─────────────────────────────┘

  Launch FF Max → press ⚡ button
        """.trimIndent()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        statusJob?.cancel()
        ShizukuManager.destroy()
        super.onDestroy()
    }
}
