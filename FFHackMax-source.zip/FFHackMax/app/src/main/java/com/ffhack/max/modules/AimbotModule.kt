package com.ffhack.max.modules

import com.ffhack.max.MemoryUtils
import com.ffhack.max.MemoryUtils.Offsets
import com.ffhack.max.ShizukuManager
import kotlin.math.*

object AimbotModule {

    var enabled      = false
    var aimKill      = false
    var onFireOnly   = true
    var bone         = "head"
    var smoothness   = 0.08f
    var fov          = 120f

    private var pid  = -1
    private var base = 0L

    fun setup(pid: Int, base: Long) { this.pid = pid; this.base = base }

    data class Enemy(
        val sx: Float, val sy: Float,
        val wx: Float, val wy: Float, val wz: Float,
        val hp: Int, val dist: Float,
        val ptr: Long
    )

    fun tick(sw: Int, sh: Int, shooting: Boolean) {
        if (!enabled || pid == -1 || base == 0L) return
        if (onFireOnly && !shooting) return

        val cx = sw / 2f; val cy = sh / 2f
        val target = nearest(getEnemies(), cx, cy) ?: return

        val dx = target.sx - cx
        val dy = target.sy - cy
        if (sqrt(dx*dx + dy*dy) > fov) return

        ShizukuManager.injectSwipe(
            cx.toInt(), cy.toInt(),
            (cx + dx * smoothness).toInt(),
            (cy + dy * smoothness).toInt(), 8
        )

        if (aimKill) killTarget(target)
    }

    private fun getEnemies(): List<Enemy> {
        val result = mutableListOf<Enemy>()
        val plList = MemoryUtils.readLong(pid, base + Offsets.PLAYER_LIST) ?: return result
        val count  = MemoryUtils.readInt(pid, plList + 0x18) ?: return result
        val local  = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return result
        val myTeam = MemoryUtils.readInt(pid, local + Offsets.TEAM_ID) ?: return result
        val lx     = MemoryUtils.readFloat(pid, local + Offsets.POS_X) ?: return result
        val lz     = MemoryUtils.readFloat(pid, local + Offsets.POS_Z) ?: return result

        for (i in 0 until minOf(count, 50)) {
            val ptr  = MemoryUtils.readLong(pid, plList + 0x20 + i * 8) ?: continue
            if (ptr == 0L) continue
            val team = MemoryUtils.readInt(pid, ptr + Offsets.TEAM_ID) ?: continue
            if (team == myTeam) continue
            val hp   = MemoryUtils.readInt(pid, ptr + Offsets.PLAYER_HP) ?: continue
            if (hp <= 0) continue

            val bOff = when (bone) { "head" -> Offsets.HEAD_BONE; "neck" -> Offsets.NECK_BONE; else -> Offsets.CHEST_BONE }
            val bPtr = MemoryUtils.readLong(pid, ptr + bOff) ?: continue
            val wx   = MemoryUtils.readFloat(pid, bPtr + 0x0C) ?: continue
            val wy   = MemoryUtils.readFloat(pid, bPtr + 0x10) ?: continue
            val wz   = MemoryUtils.readFloat(pid, bPtr + 0x14) ?: continue

            val (sx, sy) = worldToScreen(wx, wy, wz) ?: continue
            val dist = sqrt((wx - lx).pow(2) + (wz - lz).pow(2))
            result.add(Enemy(sx, sy, wx, wy, wz, hp, dist, ptr))
        }
        return result
    }

    private fun worldToScreen(wx: Float, wy: Float, wz: Float): Pair<Float,Float>? {
        val cam = base + 0x9E45BC0L
        val m   = Array(16) { i -> MemoryUtils.readFloat(pid, cam + i * 4) ?: return null }
        val cw  = m[3]*wx + m[7]*wy + m[11]*wz + m[15]
        if (cw <= 0f) return null
        val cx  = (m[0]*wx + m[4]*wy + m[8]*wz  + m[12]) / cw
        val cy  = (m[1]*wx + m[5]*wy + m[9]*wz  + m[13]) / cw
        return Pair((cx + 1f) * 0.5f * 1080f, (1f - cy) * 0.5f * 2400f)
    }

    private fun nearest(list: List<Enemy>, cx: Float, cy: Float): Enemy? =
        list.minByOrNull { (it.sx-cx).pow(2) + (it.sy-cy).pow(2) }

    private fun killTarget(e: Enemy) {
        MemoryUtils.writeInt(pid, e.ptr + Offsets.PLAYER_HP, 1)
    }
}
