package com.ffhack.max.modules

import com.ffhack.max.MemoryUtils
import com.ffhack.max.MemoryUtils.Offsets
import com.ffhack.max.VpnHackService

object LocationModule {

    var enabled   = false
    var targetX   = 0f
    var targetZ   = 0f
    var teleport  = false

    private var pid  = -1
    private var base = 0L

    fun setup(pid: Int, base: Long) { this.pid = pid; this.base = base }

    fun apply() {
        if (!enabled || pid == -1 || base == 0L) return
        val local = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return

        if (teleport) {
            MemoryUtils.writeFloat(pid, local + Offsets.POS_X, targetX)
            MemoryUtils.writeFloat(pid, local + Offsets.POS_Z, targetZ)
        }

        VpnHackService.cfg.locSpoof  = true
        VpnHackService.cfg.spoofLat  = (targetZ / 8192.0 * 180.0) - 90.0
        VpnHackService.cfg.spoofLon  = (targetX / 8192.0 * 360.0) - 180.0
    }

    fun getPos(): Triple<Float,Float,Float>? {
        if (pid == -1 || base == 0L) return null
        val local = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return null
        val x = MemoryUtils.readFloat(pid, local + Offsets.POS_X) ?: return null
        val y = MemoryUtils.readFloat(pid, local + Offsets.POS_Y) ?: return null
        val z = MemoryUtils.readFloat(pid, local + Offsets.POS_Z) ?: return null
        return Triple(x, y, z)
    }

    fun disable() { VpnHackService.cfg.locSpoof = false }
}
