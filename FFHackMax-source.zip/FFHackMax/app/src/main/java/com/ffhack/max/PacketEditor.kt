package com.ffhack.max

import java.nio.ByteBuffer
import java.nio.ByteOrder

object PacketEditor {

    private const val PKT_MOVE       = 0x07
    private const val PKT_POSITION   = 0x03
    private const val PKT_SHOOT      = 0x0A
    private const val PKT_ANTI_RPT   = 0xF1

    fun edit(payload: ByteArray, cfg: VpnHackService.HackConfig): ByteArray {
        if (payload.size < 4) return payload
        return when (payload[0].toInt() and 0xFF) {
            PKT_MOVE     -> editMove(payload, cfg)
            PKT_POSITION -> editPos(payload, cfg)
            PKT_SHOOT    -> editShoot(payload)
            PKT_ANTI_RPT -> if (cfg.antiReport) ByteArray(0) else payload
            else         -> payload
        }
    }

    private fun editMove(p: ByteArray, cfg: VpnHackService.HackConfig): ByteArray {
        if (p.size < 20) return p
        val b = ByteBuffer.wrap(p.copyOf()).order(ByteOrder.LITTLE_ENDIAN)
        if (cfg.speedMul != 1.0f) {
            b.putFloat(4,  b.getFloat(4)  * cfg.speedMul)
            b.putFloat(12, b.getFloat(12) * cfg.speedMul)
        }
        if (cfg.flyEnabled) b.putFloat(8, 5.5f)
        return b.array()
    }

    private fun editPos(p: ByteArray, cfg: VpnHackService.HackConfig): ByteArray {
        if (!cfg.locSpoof || p.size < 16) return p
        val b = ByteBuffer.wrap(p.copyOf()).order(ByteOrder.LITTLE_ENDIAN)
        b.putFloat(4,  ((cfg.spoofLon + 180.0) / 360.0 * 8192).toFloat())
        b.putFloat(12, ((cfg.spoofLat +  90.0) / 180.0 * 8192).toFloat())
        return b.array()
    }

    private fun editShoot(p: ByteArray): ByteArray {
        val b = ByteBuffer.wrap(p.copyOf()).order(ByteOrder.LITTLE_ENDIAN)
        if (p.size > 5) b.put(5, (b.get(5).toInt() and 0xFD.inv()).toByte())
        return b.array()
    }
}
