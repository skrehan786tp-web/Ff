package com.ffhack.max.modules

import com.ffhack.max.MemoryUtils
import com.ffhack.max.MemoryUtils.Offsets
import com.ffhack.max.VpnHackService

object MiscModule {

    var antiban       = true
    var noRecoil      = false
    var noReload      = false
    var unlimAmmo     = false
    var wallhack      = false
    var rapidFire     = false
    var superJump     = false
    var invisible     = false

    private var pid   = -1
    private var base  = 0L

    fun setup(pid: Int, base: Long) { this.pid = pid; this.base = base }

    fun applyAll() {
        if (pid == -1 || base == 0L) return
        val local = MemoryUtils.readLong(pid, base + Offsets.LOCAL_PLAYER) ?: return

        if (noRecoil) {
            MemoryUtils.writeFloat(pid, local + Offsets.RECOIL_X, 0f)
            MemoryUtils.writeFloat(pid, local + Offsets.RECOIL_Y, 0f)
        }

        if (unlimAmmo || noReload) {
            val wep = MemoryUtils.readLong(pid, local + Offsets.AMMO_COUNT)
            if (wep != null) {
                if (unlimAmmo) MemoryUtils.writeInt(pid, wep + Offsets.AMMO_COUNT, 999)
                if (noReload)  MemoryUtils.writeFloat(pid, wep + Offsets.RELOAD_TIME, 0f)
            }
        }

        if (superJump) MemoryUtils.writeFloat(pid, base + 0x9012AC8L, 25f)
        if (rapidFire) MemoryUtils.writeFloat(pid, local + 0x21CL, 999f)
        if (invisible) MemoryUtils.writeFloat(pid, local + 0x3C4L, 0.01f)
        if (wallhack)  MemoryUtils.writeInt(pid, base + 0x9F234C8L, 1)

        if (antiban) {
            MemoryUtils.writeInt(pid, base + Offsets.ANTICHEAT_FLAG, 0)
            MemoryUtils.writeInt(pid, base + Offsets.REPORT_FLAG, 0)
            VpnHackService.cfg.antiReport = true
        }
    }
}
