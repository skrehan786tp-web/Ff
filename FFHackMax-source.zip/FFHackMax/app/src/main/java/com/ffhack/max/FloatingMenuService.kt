package com.ffhack.max

import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.*
import android.widget.*
import com.ffhack.max.modules.*

class FloatingMenuService : Service() {

    private lateinit var wm: WindowManager
    private var menuView: View? = null
    private var btnView:  View? = null
    private var menuVisible = false

    private var btnParams: WindowManager.LayoutParams? = null
    private var startX = 0f; private var startY = 0f
    private var initX  = 0f; private var initY  = 0f

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        makeBtn()
    }

    private fun makeBtn() {
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 500 }
        btnParams = params

        val btn = Button(this).apply {
            text = "⚡"
            textSize = 18f
            setBackgroundColor(0xCC220000.toInt())
            setTextColor(0xFFFF4444.toInt())
            setPadding(24, 24, 24, 24)
        }

        btn.setOnTouchListener { _, ev ->
            when (ev.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = ev.rawX; startY = ev.rawY
                    initX  = params.x.toFloat(); initY = params.y.toFloat()
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (initX + ev.rawX - startX).toInt()
                    params.y = (initY + ev.rawY - startY).toInt()
                    wm.updateViewLayout(btn, params)
                }
                MotionEvent.ACTION_UP -> {
                    val dx = ev.rawX - startX; val dy = ev.rawY - startY
                    if (dx*dx + dy*dy < 30) toggle()
                }
            }
            true
        }

        btnView = btn
        wm.addView(btn, params)
    }

    private fun toggle() { if (menuVisible) hideMenu() else showMenu() }

    private fun showMenu() {
        menuVisible = true
        val params = WindowManager.LayoutParams(
            620, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xEE0D0D1A.toInt())
            setPadding(16, 16, 16, 16)
        }

        root.addView(TextView(this).apply {
            text = "FF MAX HACK v2.0"
            textSize = 15f
            setTextColor(0xFFFF4444.toInt())
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 12)
        })

        val toggles = listOf(
            "🎯  Aimbot"           to { v: Boolean -> AimbotModule.enabled = v },
            "💀  Aim Kill"         to { v: Boolean -> AimbotModule.aimKill = v },
            "🔥  On-Fire Only"     to { v: Boolean -> AimbotModule.onFireOnly = v },
            "⚡  Speed Hack"       to { v: Boolean -> SpeedFlyModule.speedEnabled = v; SpeedFlyModule.apply() },
            "🦅  Fly Hack"         to { v: Boolean -> SpeedFlyModule.flyEnabled = v; SpeedFlyModule.apply() },
            "📍  Location Spoof"   to { v: Boolean -> LocationModule.enabled = v; if (v) LocationModule.apply() else LocationModule.disable() },
            "🚫  No Recoil"        to { v: Boolean -> MiscModule.noRecoil = v; MiscModule.applyAll() },
            "♾️   Unlimited Ammo"  to { v: Boolean -> MiscModule.unlimAmmo = v; MiscModule.applyAll() },
            "🔁  No Reload"        to { v: Boolean -> MiscModule.noReload = v; MiscModule.applyAll() },
            "👁   Wallhack ESP"    to { v: Boolean -> MiscModule.wallhack = v; MiscModule.applyAll() },
            "🚀  Super Jump"       to { v: Boolean -> MiscModule.superJump = v; MiscModule.applyAll() },
            "⚡  Rapid Fire"       to { v: Boolean -> MiscModule.rapidFire = v; MiscModule.applyAll() },
            "👻  Invisible"        to { v: Boolean -> MiscModule.invisible = v; MiscModule.applyAll() },
            "🛡   Anti-Ban"        to { v: Boolean -> MiscModule.antiban = v; MiscModule.applyAll() },
        )

        toggles.forEach { (label, action) ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(4, 6, 4, 6)
            }
            row.addView(TextView(this).apply {
                text = label
                setTextColor(0xFFEEEEEE.toInt())
                textSize = 12f
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            val sw = Switch(this).apply {
                setOnCheckedChangeListener { _, chk -> action(chk) }
            }
            row.addView(sw)
            root.addView(row)
        }

        // speed slider
        root.addView(TextView(this).apply {
            text = "Speed ×${SpeedFlyModule.speedMul}"
            setTextColor(0xFF888888.toInt())
            textSize = 11f
            setPadding(4, 8, 0, 0)
            tag = "speedLabel"
        })
        root.addView(SeekBar(this).apply {
            max = 40; progress = 15
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, b: Boolean) {
                    SpeedFlyModule.speedMul = 1f + p / 10f
                    if (SpeedFlyModule.speedEnabled) SpeedFlyModule.apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        })

        // close btn
        root.addView(Button(this).apply {
            text = "✕ Close"
            setBackgroundColor(0xFF330000.toInt())
            setTextColor(0xFFFF4444.toInt())
            setOnClickListener { hideMenu() }
        })

        menuView = root
        wm.addView(root, params)
    }

    private fun hideMenu() {
        menuVisible = false
        menuView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        menuView = null
    }

    override fun onDestroy() {
        hideMenu()
        btnView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        super.onDestroy()
    }
}
