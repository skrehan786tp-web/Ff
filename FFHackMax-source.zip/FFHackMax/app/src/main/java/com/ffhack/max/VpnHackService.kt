package com.ffhack.max

import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log
import java.io.FileInputStream
import java.io.FileOutputStream
import java.nio.ByteBuffer
import kotlin.concurrent.thread

class VpnHackService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var running = false

    companion object {
        const val FF_PORT  = 10012
        const val FF_PORT2 = 10013
        var cfg = HackConfig()
    }

    data class HackConfig(
        var speedMul:      Float   = 1.0f,
        var flyEnabled:    Boolean = false,
        var locSpoof:      Boolean = false,
        var spoofLat:      Double  = 0.0,
        var spoofLon:      Double  = 0.0,
        var antiReport:    Boolean = true
    )

    override fun onStartCommand(intent: android.content.Intent?, flags: Int, startId: Int): Int {
        setupVpn()
        startLoop()
        return START_STICKY
    }

    private fun setupVpn() {
        vpnInterface = Builder()
            .addAddress("10.0.0.2", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("8.8.8.8")
            .setSession("FFHack")
            .setMtu(1500)
            .addDisallowedApplication(packageName)
            .establish()
        running = true
    }

    private fun startLoop() {
        thread(name = "VPN-Loop") {
            val vpnIn  = FileInputStream(vpnInterface!!.fileDescriptor)
            val vpnOut = FileOutputStream(vpnInterface!!.fileDescriptor)
            val buf    = ByteArray(32767)

            while (running) {
                try {
                    val len = vpnIn.read(buf)
                    if (len <= 0) continue

                    val ipVer = (buf[0].toInt() shr 4) and 0xF
                    if (ipVer != 4) { vpnOut.write(buf, 0, len); continue }

                    val proto = buf[9].toInt() and 0xFF
                    if (proto != 17) { vpnOut.write(buf, 0, len); continue }

                    val dport = ((buf[22].toInt() and 0xFF) shl 8) or (buf[23].toInt() and 0xFF)

                    if (dport == FF_PORT || dport == FF_PORT2) {
                        val modified = processPacket(buf, len)
                        if (modified.isNotEmpty()) vpnOut.write(modified)
                    } else {
                        vpnOut.write(buf, 0, len)
                    }
                } catch (e: Exception) {
                    Log.e("VPNHack", e.message ?: "err")
                }
            }
        }
    }

    private fun processPacket(data: ByteArray, len: Int): ByteArray {
        val pkt       = data.copyOf(len)
        val ipHdrLen  = (pkt[0].toInt() and 0xF) * 4
        val udpPayOff = ipHdrLen + 8
        if (udpPayOff >= len) return pkt

        val payload  = pkt.sliceArray(udpPayOff until len)
        val modified = PacketEditor.edit(payload, cfg)
        if (modified.isEmpty()) return ByteArray(0)

        val result = ByteArray(ipHdrLen + 8 + modified.size)
        System.arraycopy(pkt, 0, result, 0, ipHdrLen + 8)
        System.arraycopy(modified, 0, result, ipHdrLen + 8, modified.size)

        val udpLen = 8 + modified.size
        result[ipHdrLen + 4] = (udpLen shr 8).toByte()
        result[ipHdrLen + 5] = (udpLen and 0xFF).toByte()
        val ipTotal = result.size
        result[2] = (ipTotal shr 8).toByte()
        result[3] = (ipTotal and 0xFF).toByte()
        recalcChecksum(result, ipHdrLen)
        result[ipHdrLen + 6] = 0
        result[ipHdrLen + 7] = 0
        return result
    }

    private fun recalcChecksum(pkt: ByteArray, hLen: Int) {
        pkt[10] = 0; pkt[11] = 0
        var sum = 0L
        for (i in 0 until hLen step 2)
            sum += ((pkt[i].toInt() and 0xFF) shl 8) or (pkt[i+1].toInt() and 0xFF)
        while (sum shr 16 != 0L) sum = (sum and 0xFFFF) + (sum shr 16)
        val c = (sum.inv() and 0xFFFF).toInt()
        pkt[10] = (c shr 8).toByte(); pkt[11] = (c and 0xFF).toByte()
    }

    override fun onDestroy() { running = false; vpnInterface?.close(); super.onDestroy() }
}
